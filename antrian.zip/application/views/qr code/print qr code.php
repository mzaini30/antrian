<p class="hidden-print">Silahkan print halaman ini.</p>
<p>
	<img src="<?= base_url() ?>gambar/cache/<?= $qrcode ?>" class='img-thumbnail'>
</p>
<h3>Nomor antrian: <?= $nomor_antrian ?></h3>