<style type="text/css">
	.table > tbody > tr > td {
		border: none;
	}
</style>