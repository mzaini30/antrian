<nav class="navbar navbar-default">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <span class="navbar-brand">
      	<a href="<?= base_url() ?>">Besukan Online Rumah Tahanan Samarinda</a>
      </span>
    </div>
  </div><!-- /.container-fluid -->
</nav>